//task model 

export class Task {    
  constructor(
    // public id: number,
    public taskname: string,
    public description: string,
    public tasktype:string,
    public trainee:string,     
  ) {  }

}