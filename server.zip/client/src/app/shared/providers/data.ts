/*  
    This class (Data) can be used on any page we inject it into. 
 */
import { Injectable } from "@angular/core";

@Injectable()
export class Data {
 
    public storage: any;
 
    public constructor() { }
 
}